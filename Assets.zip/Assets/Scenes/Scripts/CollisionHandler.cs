﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionHandler : MonoBehaviour
{
  
    [SerializeField] float DelayTime = 1f;
    bool isTransitioning = false;
    bool colldisable;

    void Update()
    {
        CheatCode();
    }

    void CheatCode()
    {
        if (Input.GetKey(KeyCode.L))
        {
            LoadNextLevel();

        }
        else if (Input.GetKey(KeyCode.C))
        {
            colldisable = !colldisable;
        }
    }

    void OnCollisionEnter(Collision other)
    {
        if (isTransitioning || colldisable ) { return; }
        
        switch (other.gameObject.tag)
        {
            case "Safe":
                Debug.Log("It's friendly");
                break;
            case "Finish":

                NextLevelSequence();
                Debug.Log("You made it!");
                break;
            case "Fuel":
                Debug.Log("MORE FUEL FOR YOU");
                break;
            case "Respawn":
                CrashSequence();
                break;
        }
    }

   

    [SerializeField] ParticleSystem successPart;
    [SerializeField] ParticleSystem crashPart;
   

    void CrashSequence()
    {
        crashPart.Play();
        GetComponent<Mover>().enabled = false;
        Invoke("ReloadLevel", DelayTime);
    }


    void NextLevelSequence()
    {
        successPart.Play();
        GetComponent<Mover>().enabled = false;
        Invoke("LoadNextLevel", DelayTime);

    }


    void LoadNextLevel()
    {
        int currentScreenIndex = (SceneManager.GetActiveScene().buildIndex);
        int nextSceneIndex = currentScreenIndex + 1;
        if (nextSceneIndex == SceneManager.sceneCountInBuildSettings)
        {
            nextSceneIndex = 0;
        }
        SceneManager.LoadScene(nextSceneIndex);
    }

    void ReloadLevel()
    {
        int currentScreenIndex = (SceneManager.GetActiveScene().buildIndex);
        SceneManager.LoadScene(currentScreenIndex);
    }

    
}


