﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mover : MonoBehaviour
{
    Rigidbody rb;
    AudioSource aS;
    [SerializeField] float MainThrust = 100f;
    [SerializeField] float RotationThrust = 100f;
    [SerializeField] ParticleSystem MainBoostPart;
    [SerializeField] ParticleSystem LeftBoostPart;
    [SerializeField] ParticleSystem RightBoostPart;



    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        aS = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {
        ProcessThrust();
        ProcessRotation();
        
    }

    void ProcessThrust()
    {
        
        if (Input.GetKey(KeyCode.W))
        {
            rb.AddRelativeForce(Vector3.up * MainThrust * Time.deltaTime);
            
            if(!MainBoostPart.isPlaying)
            {
                MainBoostPart.Play();
            }
           


            if (!aS.isPlaying)
            {
                aS.Play();
            }
            else
            {
                aS.Stop();
            }



        }
        else
        {
            MainBoostPart.Stop();
        }
    }

    void ProcessRotation()
    {
        if (Input.GetKey(KeyCode.A))
        {
            Rotate(RotationThrust);
            if (!LeftBoostPart.isPlaying)
            {
                LeftBoostPart.Play();
            }


        }
        else
        {
            LeftBoostPart.Stop();
        }

        if (Input.GetKey(KeyCode.D))
        {
            Rotate(-RotationThrust);
            if (!RightBoostPart.isPlaying)
            {
                RightBoostPart.Play();
            }


        }
        else
        {
            RightBoostPart.Stop();
        }
    }

     void Rotate(float rotationThisFrame)
    {
        rb.freezeRotation = true; // freezing roation to manually rotate
        transform.Rotate(Vector3.forward * rotationThisFrame* Time.deltaTime);
        rb.freezeRotation = false;
    }

 

}
