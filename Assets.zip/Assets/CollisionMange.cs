﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionMange : MonoBehaviour
{
    [SerializeField] float DelayTime = 1f;
    void OnCollisionEnter(Collision other)
    {
        switch (other.gameObject.tag)
        {
            case "Safe":
                Debug.Log("It's friendly");
                break;
            case "Finish":
                NextLevelSequence();
                Debug.Log("You made it!");
                break;
            case "Fuel":
                Debug.Log("MORE FUEL FOR YOU");
                break;
            case "Respawn":
                CrashSequence();
                break;
        }
    }

    void CrashSequence()
    {

        GetComponent<Mover>().enabled = false;
        Invoke("ReloadLevel", DelayTime);
    }
       

    void NextLevelSequence()
    {
        GetComponent<Mover>().enabled = false;
        Invoke("LoadNextLevel", DelayTime);
        
    }


     void LoadNextLevel()
    {
        int currentScreenIndex = (SceneManager.GetActiveScene().buildIndex);
        int nextSceneIndex = currentScreenIndex + 1;
        if(nextSceneIndex == SceneManager.sceneCountInBuildSettings)
        {
            nextSceneIndex = 0;
        }
        SceneManager.LoadScene(nextSceneIndex);
    }

     void ReloadLevel()
    {
        int currentScreenIndex = (SceneManager.GetActiveScene().buildIndex);
        SceneManager.LoadScene(currentScreenIndex);
    }
}
